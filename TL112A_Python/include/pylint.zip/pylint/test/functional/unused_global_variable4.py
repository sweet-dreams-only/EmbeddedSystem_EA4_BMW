# pylint: disable=missing-docstring
VAR = 'pylint'  # [unused-variable]
VAR = 'pylint2'  # [unused-variable]
