"""Regression test for trailing-newlines (C0304)."""
# +1: [trailing-newlines]

