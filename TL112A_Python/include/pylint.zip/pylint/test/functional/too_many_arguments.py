# pylint: disable=missing-docstring

def stupid_function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9): # [too-many-arguments]
    return arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9
