"""Checks import order rule with nested non_import sentence"""
# pylint: disable=unused-import,relative-import,ungrouped-imports,import-error,no-name-in-module,relative-beyond-top-level
try:
    from sys import argv
except ImportError:
    pass
else:
    pass

import os
